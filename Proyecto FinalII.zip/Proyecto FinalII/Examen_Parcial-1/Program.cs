﻿

using Examen_Parcial_1.Formularios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen_Parcial_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Form_Inicio().ShowDialog();
        }
    }
}
