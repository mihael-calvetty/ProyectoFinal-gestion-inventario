﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Parcial_1.Formularios
{
    public partial class Form_Inicio : Form
    {
        public static Gestora Inventario=new Gestora();
        
        public Form_Inicio()
        {
            InitializeComponent();
            datetimefecha.Format = DateTimePickerFormat.Short;
            dataGridView1.Columns.Add("Producto", "producto");
            dataGridView1.Columns.Add("Cantidad", "cantidad");
            dataGridView1.Columns.Add("Codigo", "Codigo");
            dataGridView1.Columns.Add("Precio", "precio");
            dataGridView1.Columns.Add("Fecha de Vencimiento", "Fecha de Vencimiento");
        }
        
        private void txtstock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) {
            e.Handled = true;
            }
        }
        public void AgregarLista()
        {
            dataGridView1.Rows.Clear();
           foreach(Producto objp in Inventario.Productos)
            {
                if (objp != null)
                {
                    dataGridView1.Rows.Add(objp.Nombre, objp.Stock, objp.Codigo, objp.PrecioU,objp.Fecha.ToShortDateString());
                }
                
            }
           
        }

        private void btagregar_producto_Click(object sender, EventArgs e)
        { Producto nvproducto = new Producto(txtproducto.Text, int.Parse(txtstock.Text), txtcodigo.Text, double.Parse(txtprecio.Text), datetimefecha.Value);
            Inventario.Agregar(nvproducto);
            AgregarLista();
            txtcodigo.Text = "";
            txtprecio.Text = "";
            txtstock.Text = "";
            txtproducto.Text = "";
        }

        private void precioDelStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
         new Calculo_Stock().ShowDialog();
        }

        private void cbproductos_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
    }
}
