﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Parcial_1
{
    public class Gestora
    {
        
        public List<Producto>Productos { get; set; }
        private int i = 0;
        public Gestora()
        {
           Productos = new List<Producto>();
        }
        
        public void Agregar(Producto productos) 
        {
            Productos.Add(productos);
          
        }
        public void ProcesarInventario()
        {

        }
    }
}
