﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Parcial_1
{
    public class Gestora
    {
        
        public Producto[]Productos { get; set; }
        private int i = 0;
        public Gestora()
        {
           Productos=new Producto[3];
        }
        
        public void Agregar(Producto productos) 
        {
            Productos[i] = productos;
            i++;
          
        }
        public void ProcesarInventario()
        {

        }
    }
}
