﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Parcial_1.Formularios
{
    public partial class Calculo_Stock : Form
    {
        public Calculo_Stock()
        {
            InitializeComponent();
            Cargar();
            CargarOpciones();
        }
        
        public void Cargar()
        {
           cbproducts.Items.Clear();
          foreach(Producto objp in Form_Inicio.Inventario.Productos) 
            { 
            if (objp != null) { cbproducts.Items.Add(objp); }
            }
        }
         public void CargarOpciones()
        {
            cbopciones.Items.Clear();            
            cbopciones.Items.Add("Sumar precio del stock");
            cbopciones.Items.Add("Sumar precio de todos los productos");
        }
        public double SumarPrecio(double prec,int can)
        {
            if (can == 0) 
            {  return 0; }
            return prec+SumarPrecio(prec, can-1);
        }
        public double SumarPrecio(int i)
        {
            if (i>=Form_Inicio.Inventario.Productos.Length) return 0;
            var p = Form_Inicio.Inventario.Productos[i];
            if(p == null) return SumarPrecio(i+1);
            return (p.Stock * p.PrecioU) + SumarPrecio(i + 1);
        }

        private void btcalcular_Click(object sender, EventArgs e)
        {
            int i, can; double prec, total = 0;
           if (cbopciones.Text== "Sumar precio del stock")
            {
                 i=cbproducts.SelectedIndex;
                 can = Form_Inicio.Inventario.Productos[i].Stock;
                 prec = Form_Inicio.Inventario.Productos[i].PrecioU;
                prec=SumarPrecio(prec, can);
                label3.Text = "El precio de todo el stock de " + Form_Inicio.Inventario.Productos[i].Nombre+" es: " +prec.ToString();
           }
           if (cbopciones.Text== "Sumar precio de todos los productos")
            {
                i = 0;

                total = SumarPrecio(i);
                label3.Text=total.ToString();
            }
        }

        private void cbproducts_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbopciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled= true;
        }
    }
}
