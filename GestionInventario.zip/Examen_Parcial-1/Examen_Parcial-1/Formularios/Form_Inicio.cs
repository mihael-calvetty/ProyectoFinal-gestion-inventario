﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_Parcial_1.Formularios
{
    public partial class Form_Inicio : Form
    {
        public static Gestora Inventario=new Gestora();
        public Form_Inicio()
        {
            InitializeComponent();
            CargarProductos();
            dataGridView1.Columns.Add("Producto", "producto");
            dataGridView1.Columns.Add("Cantidad", "cantidad");
            dataGridView1.Columns.Add("Codigo", "Codigo");
            dataGridView1.Columns.Add("Precio", "precio");
        }
        public void CargarProductos() {
        cbproductos.Items.Clear();
            cbproductos.Items.Add("Arroz");
            cbproductos.Items.Add("Harina");
            cbproductos.Items.Add("Trigo");
            cbproductos.Items.Add("Maiz");
            cbproductos.Items.Add("Fideo");
        }
        private void txtstock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) {
            e.Handled = true;
            }
        }
        public void AgregarLista()
        {
            dataGridView1.Rows.Clear();
           foreach(Producto objp in Inventario.Productos)
            {
                if (objp != null)
                {
                    dataGridView1.Rows.Add(objp.Nombre, objp.Stock, objp.Codigo, objp.PrecioU);
                }
                
            }
           
        }

        private void btagregar_producto_Click(object sender, EventArgs e)
        { Producto nvproducto = new Producto(cbproductos.Text, int.Parse(txtstock.Text), txtcodigo.Text, double.Parse(txtprecio.Text));
            Inventario.Agregar(nvproducto);
            AgregarLista();
            txtcodigo.Text = "";
            txtprecio.Text = "";
            txtstock.Text = "";
            cbproductos.Text = "";
        }

        private void precioDelStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
         new Calculo_Stock().ShowDialog();
        }
    }
}
